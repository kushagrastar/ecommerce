from django.apps import AppConfig


class SearchAppConfig(AppConfig):
    name = 'search_app'
